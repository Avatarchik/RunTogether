package com.unity.uiwidgets.plugin;

public class Utils {
    public static final String TAG = "UIWidgets";
}
